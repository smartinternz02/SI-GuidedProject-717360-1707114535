<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Continue shopping</name>
   <tag></tag>
   <elementGuidId>78c1d532-3186-4180-91c8-ed0b0088400b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.a-button.a-button-primary.a-span12</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>ec6eb098-af68-4283-b3e4-1359c5730975</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-button a-button-primary a-span12</value>
      <webElementGuid>11d4f052-ea13-4813-a6bd-de26a158f916</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                        
                                            Continue shopping
                                        
                                    </value>
      <webElementGuid>7c87ed7b-fa3f-4d87-ac87-d66a487e09d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;a-no-js&quot;]/body[1]/div[@class=&quot;a-container a-padding-double-large&quot;]/div[@class=&quot;a-row a-spacing-double-large&quot;]/div[@class=&quot;a-section&quot;]/div[@class=&quot;a-box a-color-offset-background&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/form[1]/div[@class=&quot;a-section a-spacing-extra-large&quot;]/div[@class=&quot;a-row&quot;]/span[@class=&quot;a-button a-button-primary a-span12&quot;]</value>
      <webElementGuid>2add05cb-94ee-40ce-8464-b766fefc7913</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span</value>
      <webElementGuid>a11d2153-31ad-4950-9647-7ffece81d9bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                                        
                                            Continue shopping
                                        
                                    ' or . = '
                                        
                                            Continue shopping
                                        
                                    ')]</value>
      <webElementGuid>71b2a761-1797-4955-b477-d008fcc5d7a9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
