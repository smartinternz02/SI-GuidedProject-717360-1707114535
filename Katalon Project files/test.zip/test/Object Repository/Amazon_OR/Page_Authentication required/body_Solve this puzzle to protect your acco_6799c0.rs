<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_Solve this puzzle to protect your acco_6799c0</name>
   <tag></tag>
   <elementGuidId>8f64ef4c-51d5-4ac6-a1a4-4c99a4d5de1b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>body.a-aui_72554-c.a-aui_accordion_a11y_role_354025-c.a-aui_killswitch_csa_logger_372963-c.a-aui_launch_2021_ally_fixes_392482-c.a-aui_pci_risk_banner_210084-c.a-aui_preload_261698-c.a-aui_rel_noreferrer_noopener_309527-c.a-aui_template_weblab_cache_333406-c.a-aui_tnr_v2_180836-c.a-meter-animate</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
      <webElementGuid>5399186f-339a-4863-8e54-f83b8db34e66</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-aui_72554-c a-aui_accordion_a11y_role_354025-c a-aui_killswitch_csa_logger_372963-c a-aui_launch_2021_ally_fixes_392482-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-meter-animate</value>
      <webElementGuid>ca42487d-2a13-4307-b6a5-8e551744cbfa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>{}






  
    

    
      



  
  

  
  
    
    
      

    
      
    
  


    
  










Solve this puzzle to protect your account






       Enter the letters and numbers above 





      
          See new characters
        
        
            Hear the characters
          

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-new-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;newCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          See new characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-alternative-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;alternativeCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          Hear the characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

Continue

  
    P.when('A').execute(function(A){
      var $ = A.$;
      $('#cvf_captcha_js_enabled_metric_id').val(&quot;1&quot;);
    });
  







  .auth-footer-separator {
    display: inline-block;
    width: 20px;
  }





  
    
      
    

    
      
        
          
        

        
      

      
        

        
          
            Conditions of Use
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Privacy Notice
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Help
          
        
      

      
    
  

  
    
      © 1996-2024, Amazon.com, Inc. or its affiliates
    
  



id(&quot;cvf-page-content&quot;)/div[@class=&quot;a-row a-spacing-none&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/div[@class=&quot;a-row a-spacing-base&quot;]/div[@class=&quot;a-section a-text-center cvf-captcha-img&quot;]/img[1]</value>
      <webElementGuid>9c577859-e499-4cc9-b330-0ae8a2f9c430</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition&quot;]/body[@class=&quot;a-aui_72554-c a-aui_accordion_a11y_role_354025-c a-aui_killswitch_csa_logger_372963-c a-aui_launch_2021_ally_fixes_392482-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-meter-animate&quot;]</value>
      <webElementGuid>cbe7ebcf-b433-42ba-93f9-6df1c716148e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
      <webElementGuid>17e6d3e5-d096-4436-9318-34d475cc3f05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = concat(&quot;{}






  
    

    
      



  
  

  
  
    
    
      

    
      
    
  


    
  










Solve this puzzle to protect your account






       Enter the letters and numbers above 





      
          See new characters
        
        
            Hear the characters
          

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-new-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;newCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          See new characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-alternative-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;alternativeCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          Hear the characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

Continue

  
    P.when(&quot; , &quot;'&quot; , &quot;A&quot; , &quot;'&quot; , &quot;).execute(function(A){
      var $ = A.$;
      $(&quot; , &quot;'&quot; , &quot;#cvf_captcha_js_enabled_metric_id&quot; , &quot;'&quot; , &quot;).val(&quot;1&quot;);
    });
  







  .auth-footer-separator {
    display: inline-block;
    width: 20px;
  }





  
    
      
    

    
      
        
          
        

        
      

      
        

        
          
            Conditions of Use
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Privacy Notice
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Help
          
        
      

      
    
  

  
    
      © 1996-2024, Amazon.com, Inc. or its affiliates
    
  



id(&quot;cvf-page-content&quot;)/div[@class=&quot;a-row a-spacing-none&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/div[@class=&quot;a-row a-spacing-base&quot;]/div[@class=&quot;a-section a-text-center cvf-captcha-img&quot;]/img[1]&quot;) or . = concat(&quot;{}






  
    

    
      



  
  

  
  
    
    
      

    
      
    
  


    
  










Solve this puzzle to protect your account






       Enter the letters and numbers above 





      
          See new characters
        
        
            Hear the characters
          

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-new-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;newCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          See new characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-alternative-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;alternativeCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          Hear the characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

Continue

  
    P.when(&quot; , &quot;'&quot; , &quot;A&quot; , &quot;'&quot; , &quot;).execute(function(A){
      var $ = A.$;
      $(&quot; , &quot;'&quot; , &quot;#cvf_captcha_js_enabled_metric_id&quot; , &quot;'&quot; , &quot;).val(&quot;1&quot;);
    });
  







  .auth-footer-separator {
    display: inline-block;
    width: 20px;
  }





  
    
      
    

    
      
        
          
        

        
      

      
        

        
          
            Conditions of Use
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Privacy Notice
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Help
          
        
      

      
    
  

  
    
      © 1996-2024, Amazon.com, Inc. or its affiliates
    
  



id(&quot;cvf-page-content&quot;)/div[@class=&quot;a-row a-spacing-none&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/div[@class=&quot;a-row a-spacing-base&quot;]/div[@class=&quot;a-section a-text-center cvf-captcha-img&quot;]/img[1]&quot;))]</value>
      <webElementGuid>8f003b6b-10bb-4271-9c72-26880800bd92</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
